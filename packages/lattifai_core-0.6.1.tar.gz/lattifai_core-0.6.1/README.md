# Lattifai-CORE

Lattifai: Next-generation AI-powered multimodal processing and analysis platform.

## Installation

```
pip install lattifai-core
```
