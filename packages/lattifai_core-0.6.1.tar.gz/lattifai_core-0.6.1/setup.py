from setuptools import setup

setup(
    name="lattifai_core",
    version="0.6.1",
    packages=["lattifai_core", "lattifai_core.client"],
    package_dir={"": "src"},
    description="Lattifai Core Client - API client for Lattifai services",
    author="The Lattifai Development Team",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.9",
    install_requires=[
        "httpx",
        "cryptography",
    ],
    zip_safe=False,
)
