"""Lattifai Core - Client Module"""

__version__ = "0.6.1"

from .client import *
