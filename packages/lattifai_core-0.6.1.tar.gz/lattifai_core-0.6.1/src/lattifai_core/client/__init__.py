from .core import (
    ApiKeyAuthError,
    ApiKeyPermissionError,
    ApiKeyVerificationError,
    SpeakerDiarizationPermissionError,
    SyncAPIClient,
    TranscriptionPermissionError,
)

__all__ = [
    "SyncAPIClient",
    "ApiKeyVerificationError",
    "ApiKeyAuthError",
    "ApiKeyPermissionError",
    "SpeakerDiarizationPermissionError",
    "TranscriptionPermissionError",
]
