"""Base client classes for LattifAI Core."""

import base64
import logging
import os
import time
from abc import ABC
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

import httpx
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from dotenv import find_dotenv, load_dotenv

# Setup internal logger
logging.getLogger("httpx").setLevel(logging.WARNING)
logger = logging.getLogger("lattifai_core.client")


class ConfigurationError(Exception):
    """Error raised when there is a configuration issue."""

    pass


class ApiKeyVerificationError(Exception):
    """Base error for API key verification issues."""

    pass


class ApiKeyAuthError(ApiKeyVerificationError):
    """
    Error raised when the API Key is invalid, expired, or fails cryptographic verification.
    Corresponds to '1. Whether it is a reasonable API KEY'.
    """

    pass


class ApiKeyPermissionError(ApiKeyVerificationError):
    """
    Error raised when the API Key is valid, but lacks permission for a specific feature.
    Corresponds to '2. PERMISSION permission is available'.
    """

    pass


class SpeakerDiarizationPermissionError(ApiKeyPermissionError):
    """
    Error raised when Speaker Diarization is not enabled in the active license.
    Speaker Diarization is available in Starter, Creator, and Pro plans.
    """

    pass


class TranscriptionPermissionError(ApiKeyPermissionError):
    """
    Error raised when Speech To Text (Transcription) is not enabled in the active license.
    Speech To Text is available in Creator and Pro plans.
    """

    pass


@dataclass
class CoreClientConfig:
    """
    Core configuration for API Client.
    Using dataclasses to avoid pydantic dependency in core.
    """

    api_key: Optional[str] = field(default=None)
    base_url: str = "https://api.lattifai.com/v1"
    timeout: float = 120.0
    max_retries: int = 2
    default_headers: Optional[Dict[str, str]] = field(default=None)

    def __post_init__(self):
        # Auto-load environment variables
        load_dotenv(find_dotenv(usecwd=True))

        if self.api_key is None:
            self.api_key = os.environ.get("LATTIFAI_API_KEY")

        if self.base_url == "https://api.lattifai.com/v1":
            env_base_url = os.environ.get("LATTIFAI_BASE_URL")
            if env_base_url:
                self.base_url = env_base_url

        if self.timeout <= 0:
            raise ValueError("timeout must be greater than 0")
        if self.max_retries < 0:
            raise ValueError("max_retries must be non-negative")


# Public Key for License Verification Encryption
LICENSE_PUBLIC_KEY_PEM = """-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA7K6XNQO99eMU90EsfS96
XTg7wQj7tMuVk7GMCrD0OmWE9bG0+gprPVVN26/rfQDnvqOCsrIyrMbOTWT00tEc
Xwn1TdrJvQdjuaNrpj03szr4smKeBXmMIS+Db6Ji8bj2jGVcPD1gQli9HAX7tWDW
G9RXW/A12DgyXygJB7F1q5dQNuZMKFZDDdHOt2VLPu7W7PIB6cVnMNII22SsbSqW
Zywb9mupfJulzb4Afi5XjWiCxIOo1F/kDt3Zai8SyG3oCye4p39S3DyIVpJNh7Xz
fos5wFaeaD1s1yz0Dyywfmokh0IMyjacKWgkYDBS9iCwBGjCA4rQjetyW0UNgiE+
vQIDAQAB
-----END PUBLIC KEY-----"""


class BaseAPIClient(ABC):
    """Abstract base class for API clients."""

    def __init__(
        self,
        config: CoreClientConfig,
    ) -> None:
        if config.api_key is None:
            # Check environment variable one last time
            config.api_key = os.environ.get("LATTIFAI_API_KEY")

        if config.api_key is None:
            raise ConfigurationError(
                "The api_key client option must be set either by passing api_key to the client "
                "or by setting the LATTIFAI_API_KEY environment variable"
            )

        # SDK Config -> Client Config
        config = CoreClientConfig(
            api_key=config.api_key,
            timeout=config.timeout,
            max_retries=config.max_retries,
            default_headers=config.default_headers,
        )

        self._api_key = config.api_key
        self._base_url = config.base_url
        self._timeout = config.timeout
        self._max_retries = config.max_retries

        headers = {
            "User-Agent": "LattifAI/Core",
            # We still send Authorization header for standard requests,
            # but verify_license will use encrypted payload.
            "Authorization": f"Bearer {self._api_key}",
        }
        if config.default_headers:
            headers.update(config.default_headers)
        self._default_headers = headers

        # Internal verification state
        self._is_verified = False
        self._license_data = {}

    def check_permission(self, feature: str) -> None:
        """Check if the verified license includes the requested feature."""
        if not self._is_verified:
            # Attempt verification first
            self.verify_license()

        features = self._license_data.get("features", [])
        if "all" in features:
            return

        if feature not in features:
            msg = f"Feature '{feature}' is not enabled in your current plan."
            if feature == "diarization":
                raise SpeakerDiarizationPermissionError(msg)
            elif feature == "transcription":
                raise TranscriptionPermissionError(msg)
            else:
                raise ApiKeyPermissionError(msg)

    def verify_license(self, raise_on_error: bool = True) -> bool:
        """
        Verify the API KEY with the server.
        The API Key is encrypted using the embedded Public Key before being sent.
        The Server Response is verified using the embedded Public Key (Signature Verification).
        This method is intended to be protected/compiled.
        """
        try:
            # 1. ENCRYPTION: Encrypt the API key
            public_key = serialization.load_pem_public_key(LICENSE_PUBLIC_KEY_PEM.encode())

            encrypted = public_key.encrypt(
                self._api_key.encode(),
                padding.OAEP(mgf=padding.MGF1(algorithm=hashes.SHA256()), algorithm=hashes.SHA256(), label=None),
            )

            encrypted_b64 = base64.b64encode(encrypted).decode("utf-8")

            # 2. REQUEST: Make a request to the auth endpoint
            response = self.post("/api-keys/verify", json={"encrypted_data": encrypted_b64})

            if response.status_code == 200:
                resp_json = response.json()

                # 3. VERIFICATION: Validate Signature
                signature_b64 = resp_json.get("signature")
                data = resp_json.get("data")

                if not signature_b64 or not data:
                    msg = "Invalid license response structure"
                    logger.error(msg)
                    if raise_on_error:
                        raise ApiKeyAuthError(msg)
                    return False

                # Canonicalize data for verification (must match server's signing method)
                import json

                payload_bytes = json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")

                try:
                    signature_bytes = base64.b64decode(signature_b64)
                    public_key.verify(
                        signature_bytes,
                        payload_bytes,
                        padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
                        hashes.SHA256(),
                    )
                    # Verification Successful!
                except Exception as e:
                    msg = f"Security Alert: API KEY signature verification failed! Potential MITM attack. {e}"
                    logger.critical(msg)
                    if raise_on_error:
                        raise ApiKeyAuthError(msg)
                    return False

                # 4. VALIDITY CHECK
                if data.get("valid") is True:
                    # # Check timestamp freshness (e.g. within 5 minutes)
                    # timestamp = data.get("timestamp", 0)
                    # now = int(time.time())
                    # if abs(now - timestamp) > 300: # 5 minutes skew allowed
                    #     logger.warning("License response timestamp too old or in future.")
                    #     # return False # Strict mode

                    # Check Key Consistency (Anti-replay for different keys)
                    server_key_check = data.get("key_check", "")
                    if server_key_check:
                        import hashlib

                        local_key_hash = hashlib.sha256(self._api_key.encode("utf-8")).hexdigest()
                        if local_key_hash != server_key_check:
                            msg = "Security Alert: API KEY consistency check failed! Server responded for a different key."
                            logger.critical(msg)
                            if raise_on_error:
                                raise ApiKeyAuthError(msg)
                            return False

                    self._is_verified = True
                    self._license_data = data
                    return True
                else:
                    msg = "API KEY is invalid or expired."
                    if raise_on_error:
                        raise ApiKeyAuthError(msg)
                    return False

            msg = f"API KEY verification failed: {response.text}"
            logger.error(msg)
            if raise_on_error:
                raise ApiKeyAuthError(msg)
            return False
        except Exception as e:
            msg = f"API KEY verification error: {e}"
            logger.error(msg)
            if raise_on_error:
                raise ApiKeyAuthError(msg)
            return False

    def get_api_key(self) -> str:
        """Return the API key."""
        return self._api_key

    def close(self):
        """Close resources."""
        pass


class SyncAPIClient(BaseAPIClient):
    """Synchronous API client."""

    def __init__(self, config: CoreClientConfig) -> None:
        super().__init__(config)
        if httpx is None:
            raise ImportError("The 'httpx' library is required for SyncAPIClient. Please install it.")

        self._client = httpx.Client(
            base_url=self._base_url,
            timeout=self._timeout,
            headers=self._default_headers,
        )

        # Auto-verify on init? Or let the user call it?
        # For security, core logic often auto-verifies.
        self.verify_license()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def _request(
        self,
        method: str,
        url: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> httpx.Response:
        """Make an HTTP request with retry logic."""
        last_exception = None
        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.request(method=method, url=url, json=json, **kwargs)
                response.raise_for_status()
                return response
            except httpx.HTTPStatusError as e:
                # Retry on server errors (5xx)
                if 500 <= e.response.status_code < 600:
                    last_exception = e
                    if attempt < self._max_retries:
                        sleep_time = 0.5 * (2**attempt)  # Exponential backoff
                        logger.warning(
                            f"Request failed with {e.response.status_code}. Retrying in {sleep_time:.1f}s ({attempt + 1}/{self._max_retries})..."
                        )
                        time.sleep(sleep_time)
                        continue
                raise e
            except httpx.RequestError as e:
                # Retry on connection errors
                last_exception = e
                if attempt < self._max_retries:
                    sleep_time = 0.5 * (2**attempt)
                    logger.warning(
                        f"Connection error: {e}. Retrying in {sleep_time:.1f}s ({attempt + 1}/{self._max_retries})..."
                    )
                    time.sleep(sleep_time)
                    continue
                raise e

        if last_exception:
            raise last_exception
        return None  # Should not be reached

    def post(self, api_endpoint: str, *, json: Optional[Dict[str, Any]] = None, **kwargs) -> httpx.Response:
        """Make a POST request to the specified API endpoint."""
        return self._request("POST", api_endpoint, json=json, **kwargs)
