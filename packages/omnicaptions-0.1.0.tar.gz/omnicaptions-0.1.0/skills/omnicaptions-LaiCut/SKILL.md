---
name: omnicaptions-LaiCut
description: Use when aligning subtitles with audio/video using forced alignment. Corrects subtitle timing to match actual speech. Uses LattifAI Lattice-1 model. More features coming (translate, speaker diarization).
allowed-tools: Bash(omnicaptions:*)
---

# LaiCut

LattifAI's audio-text processing toolkit. Currently supports forced alignment, with translate and speaker diarization coming soon.

## When to Use

- **Sync misaligned subtitles** - Fix timing drift in downloaded captions
- **Align manual transcripts** - Match text to speech precisely
- **Post-transcription alignment** - Improve timing from auto-generated subtitles
- **Multi-format support** - SRT, VTT, ASS, LRC, TXT, MD

## When NOT to Use

- Need full transcription (use `/omnicaptions:transcribe`)
- No existing subtitle/transcript (nothing to align)
- Very short clips (<5 seconds)

## Setup

```bash
pip install $PLUGIN_DIR/packages/lattifai_core-*.tar.gz \
  "$(ls $PLUGIN_DIR/packages/lattifai_captions-*.tar.gz)[splitting]" \
  $PLUGIN_DIR/packages/omnicaptions-*.tar.gz
pip install "$(ls $PLUGIN_DIR/packages/lattifai-*.tar.gz)[alignment]"
```

## API Key

Priority: `LATTIFAI_API_KEY` env → `.env` file → `~/.config/omnicaptions/config.json`

If not set, ask user directly: `请输入 LattifAI API key（从 https://lattifai.com/dashboard/api-keys 获取）：`

Then run with `-k <key>`. Key will be saved to config file automatically.

## CLI Usage

```bash
# Basic alignment
omnicaptions LaiCut audio.mp3 subtitle.srt

# Specify output file
omnicaptions LaiCut video.mp4 transcript.md -o aligned.srt

# Convert format during alignment
omnicaptions LaiCut audio.wav caption.vtt -f srt
```

| Option | Description |
|--------|-------------|
| `-o, --output` | Output file (default: `<caption>_LaiCut.<ext>`) |
| `-f, --format` | Output format (default: same as input) |
| `-k, --api-key` | LattifAI API key |
| `-v, --verbose` | Show progress |

## Common Mistakes

| Mistake | Fix |
|---------|-----|
| No API key | Set `LATTIFAI_API_KEY` or use `-k` |
| Audio format error | Convert to WAV/MP3/M4A first |
| Empty output | Check caption has text content |

## Related Skills

| Skill | Use When |
|-------|----------|
| `/omnicaptions:transcribe` | Generate transcript first |
| `/omnicaptions:convert` | Convert caption formats |
| `/omnicaptions:translate` | Translate after alignment |

### Workflow Examples

**重要**：双语字幕应在对齐之后生成，因为 LaiCut 基于原始音频对齐文本。音视频输入无需预处理，内部会自动处理。

```bash
# 无字幕：转录 → 对齐 → 翻译(双语)
omnicaptions transcribe video.mp4
omnicaptions LaiCut video.mp4 video_GeminiUnd.md -o video_LaiCut.srt
omnicaptions translate video_LaiCut.srt -l zh --bilingual

# 有字幕：下载 → 对齐 → 翻译(双语)
omnicaptions download "https://youtu.be/xxx"
omnicaptions LaiCut xxx.mp4 xxx.en.vtt -o xxx_LaiCut.srt
omnicaptions translate xxx_LaiCut.srt -l zh --bilingual
```
